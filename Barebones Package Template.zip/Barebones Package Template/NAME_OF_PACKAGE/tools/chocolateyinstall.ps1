﻿$ErrorActionPreference = 'Stop'; # stop on all errors
$toolsDir   = "$(Split-Path -parent $MyInvocation.MyCommand.Definition)"
$fileLocation = Join-Path $toolsDir 'NAME_OF_INSTALLER' # Include the extension. Example: Software.msi, Executable.exe

$packageArgs = @{
  packageName   = $env:ChocolateyPackageName
  unzipLocation = $toolsDir
  fileType      = 'EXE_MSI_OR_MSU' #only one of these: exe, msi, msu
  file         = $fileLocation
  softwareName  = 'NAME_OF_PACKAGE*' #part or all of the Display Name as you see it in Programs and Features. It should be enough to be unique
  silentArgs    = "/quiet /qn /norestart /l*v `"$($env:TEMP)\$($packageName).$($env:chocolateyPackageVersion).MsiInstall.log`"" # This will work for about 90% of MSI/MSPs. EXEs will usually have other options. CHECK FOR CLI INSTALLATION SWITCHES FOR THAT SOFTWARE!
}

Install-ChocolateyPackage @packageArgs